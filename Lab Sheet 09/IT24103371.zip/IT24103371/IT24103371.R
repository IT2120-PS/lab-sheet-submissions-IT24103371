# setting directory
setwd("C:\\Users\\aofer\\OneDrive\\Desktop\\IT24103371")

# For the Question; Mean = 45 and Standard deviation = 2
# Generate a random sample of size 25 for the baking time
y = rnorm(25, mean = 45, sd = 2)
y

# Test whether the average baking time is less than 46 minutes at a 5% level of significance
result =t.test(y , mu = 46 , alternative = "less")
result

result$p.value
