# setting directory
setwd("C:\\Users\\aofer\\OneDrive\\Desktop\\IT24103371")

#01.i
# Binomial Distribution (X)
# Here, random variable X has binomal distribution with n= 50 and p=0.85

#ii. probability that at least 47 students passed the test
1- pbinom(46, 50, 0.85, lower.tail = TRUE)

#02.i
# The random variable (X)
#Number of customer calls received in an hour

#ii.The distribution of X
#Here, random variable X with lamda = 12

#iii.The probability that exactly 15 calls are received in an hour
dpois(15,12)