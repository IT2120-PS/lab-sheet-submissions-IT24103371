# setting directory
setwd("C:\\Users\\aofer\\OneDrive\\Desktop\\IT24103371")

#01.
#Uniform Distribution
#Here, random variable X follows a uniform distribution with a=0 and b=40
punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)

#02.
#Exponential Distribution
#Here, random variable X has exponential distribution with lambda=1/3
pexp(2, rate = 1/3, lower.tail = TRUE)

#03.i
#Normal Distribution
#Here, random variable X has normal distribution with mean=100 and standard deviation=15
1- pnorm(130, mean = 100, sd = 15, lower.tail = TRUE)

#03.ii
qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)