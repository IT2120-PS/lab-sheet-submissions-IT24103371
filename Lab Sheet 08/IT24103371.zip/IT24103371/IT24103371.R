# setting directory
setwd("C:\\Users\\aofer\\OneDrive\\Desktop\\IT24103371")

# Importing the dataset
data = read.table("Exercise - LaptopsWeights.txt", header = TRUE)
fix(data)

# 01. Calculate the population mean and population standard deviation
popmn = mean(data$Weight.kg.)
popmn
popsd = sd(data$Weight.kg.)
popsd

# 02. . Draw 25 random samples of size 6 (with replacement)
samples = c()
n = c()

for (i in 1:25) {
  s = sample (data$Weight.kg., 6 , replace = TRUE)
  samples = cbind(samples, s)
  n = c(n, paste('S',i))
}

# Calculate the sample mean and sample standard deviation for each sample
colnames(samples)=n

s.means = apply(samples,2, mean)
s.means
s.sd = apply(samples,2, sd)
s.sd

# 03. Calculate the mean and standard deviation of the 25 sample means
samplemean = mean(s.means)
samplemean
samplesd = sd(s.means)
samplesd

# Compare Population Mean and the Mean of Sample Means
popmn
samplemean

# Compare Population standard deviation and the standard deviation of Sample Means
trueSD = popsd/6
trueSD
samplesd
